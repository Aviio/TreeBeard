﻿using System;
using System.Reactive.Linq;
using TreeBeard;
using TreeBeard.Inputs;

public class $safeitemname$ : AbstractInput
{
    public override IObservable<Event> Execute()
    {
        throw new NotImplementedException();
    }

    public override void Initialize(params string[] args)
    {
        throw new NotImplementedException();
    }
}
