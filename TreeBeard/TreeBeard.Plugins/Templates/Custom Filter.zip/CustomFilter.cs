﻿using System;
using TreeBeard;
using TreeBeard.Filters;

public class $safeitemname$ : AbstractFilter
{
    public override Event Execute(Event value)
    {
        throw new NotImplementedException();
    }

    public override void Initialize(params string[] args)
    {
        throw new NotImplementedException();
    }
}
