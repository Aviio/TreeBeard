﻿using System;
using TreeBeard;
using TreeBeard.Outputs;

public class $safeitemname$ : AbstractOutput
{
    public override void Execute(Event value)
    {
        throw new NotImplementedException();
    }

    public override void Initialize(params string[] args)
    {
        throw new NotImplementedException();
    }
}

