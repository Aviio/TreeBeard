﻿using System;
using TreeBeard;
using TreeBeard.Interfaces;

public class $safeitemname$ : IOutput
{
    public void Execute(Event value)
    {
        throw new NotImplementedException();
    }

    public void Initialize(params string[] args)
    {
        throw new NotImplementedException();
    }
}

